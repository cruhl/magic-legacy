"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var aws = require("aws-sdk");
aws.APIGateway.Types;
exports.generateTwiml = function (event, context, callback) {
    var response = {
        statusCode: 200,
        contentType: "application/json",
        body: { message: "Success!" }
    };
    callback(null, response);
};
//# sourceMappingURL=generateTwiml.js.map